﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DisplayData
{
    public partial class Form1 : Form
    {
        private BooksDatabase.BooksEntities DbContext = new BooksDatabase.BooksEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void DisplayResult(object sender, EventArgs e)
        {
            // Displaying authors and titles sorted by a book title
            var authorsAndTitles = from book in DbContext.Titles
                                   from author in book.Authors
                                   orderby book.Title1
                                   select new
                                   {
                                       author.FirstName,
                                       author.LastName,
                                       book.Title1
                                   };

            DisplayResults.AppendText("\r\n\r\nList of book titles and authors who wrote them");
            foreach (var x in authorsAndTitles)
            {
                DisplayResults.AppendText(String.Format("\r\n\t{0,-10} {1,-10} {2}", x.LastName, x.FirstName, x.Title1));
            }
            // Displaying the data sorted by title and each title sorts author names alphabetically
            var sortedByLastName = from book in DbContext.Titles
                                   from author in book.Authors
                                   orderby book.Title1, author.LastName, author.FirstName
                                   select new
                                   {
                                       author.FirstName,
                                       author.LastName,
                                       book.Title1
                                   };

            DisplayResults.AppendText("\r\n\r\nAuthors sorted by each title");
            foreach (var x in sortedByLastName)
            {
                DisplayResults.AppendText(String.Format("\r\n\t{0,-10} {1,-10} {2}", x.LastName, x.FirstName, x.Title1));
            } 
            // Displaying the data which is groped by title, sorted by title, and author names are in alphabetical order
            var authorsByTitle = from book in DbContext.Titles
                                 orderby book.Title1
                                 select new
                                 {
                                     Title = book.Title1,
                                     Authors = from author in book.Authors
                                               orderby author.LastName, author.FirstName
                                               select author.FirstName + " " + author.LastName                                             
                                 };
            DisplayResults.AppendText(String.Format("\r\n\r\nList of all the authors grouped by title and sorted alphabetically by the last name"));
            foreach (var book in authorsByTitle)
            {
                DisplayResults.AppendText(String.Format("\r\n\t{0}: ", book.Title));
                foreach (var author in book.Authors)
                {
                    DisplayResults.AppendText(String.Format("\r\n\t\t{0, -10}", author));
                }
            }
        }
    }
}
